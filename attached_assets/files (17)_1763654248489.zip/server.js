const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs').promises;
const path = require('path');

const app = express();
// Use Replit's PORT environment variable or default to 3000
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, 'database.json');

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

// Initialize database file if it doesn't exist
async function initDatabase() {
  try {
    await fs.access(DB_FILE);
  } catch {
    await fs.writeFile(DB_FILE, JSON.stringify({ dealerships: [] }, null, 2));
    console.log('✓ Database initialized');
  }
}

// Read database
async function readDatabase() {
  const data = await fs.readFile(DB_FILE, 'utf8');
  return JSON.parse(data);
}

// Write database
async function writeDatabase(data) {
  await fs.writeFile(DB_FILE, JSON.stringify(data, null, 2));
}

// API Routes

// Get all dealerships
app.get('/api/dealerships', async (req, res) => {
  try {
    const db = await readDatabase();
    res.json(db.dealerships);
  } catch (error) {
    console.error('Error reading dealerships:', error);
    res.status(500).json({ error: 'Failed to read dealerships' });
  }
});

// Add dealership
app.post('/api/dealerships', async (req, res) => {
  try {
    const db = await readDatabase();
    const newDealership = {
      id: Date.now(),
      ...req.body,
      inventory: [],
      createdAt: new Date().toISOString()
    };
    db.dealerships.push(newDealership);
    await writeDatabase(db);
    res.json(newDealership);
  } catch (error) {
    console.error('Error adding dealership:', error);
    res.status(500).json({ error: 'Failed to add dealership' });
  }
});

// Update dealership
app.put('/api/dealerships/:id', async (req, res) => {
  try {
    const db = await readDatabase();
    const index = db.dealerships.findIndex(d => d.id === parseInt(req.params.id));
    if (index === -1) {
      return res.status(404).json({ error: 'Dealership not found' });
    }
    db.dealerships[index] = {
      ...db.dealerships[index],
      ...req.body,
      id: parseInt(req.params.id),
      inventory: db.dealerships[index].inventory
    };
    await writeDatabase(db);
    res.json(db.dealerships[index]);
  } catch (error) {
    console.error('Error updating dealership:', error);
    res.status(500).json({ error: 'Failed to update dealership' });
  }
});

// Delete dealership
app.delete('/api/dealerships/:id', async (req, res) => {
  try {
    const db = await readDatabase();
    db.dealerships = db.dealerships.filter(d => d.id !== parseInt(req.params.id));
    await writeDatabase(db);
    res.json({ success: true });
  } catch (error) {
    console.error('Error deleting dealership:', error);
    res.status(500).json({ error: 'Failed to delete dealership' });
  }
});

// Add car to dealership
app.post('/api/dealerships/:id/cars', async (req, res) => {
  try {
    const db = await readDatabase();
    const dealership = db.dealerships.find(d => d.id === parseInt(req.params.id));
    if (!dealership) {
      return res.status(404).json({ error: 'Dealership not found' });
    }
    const newCar = {
      id: Date.now(),
      ...req.body,
      addedDate: new Date().toISOString()
    };
    dealership.inventory.push(newCar);
    await writeDatabase(db);
    res.json(newCar);
  } catch (error) {
    console.error('Error adding car:', error);
    res.status(500).json({ error: 'Failed to add car' });
  }
});

// Update car
app.put('/api/dealerships/:dealershipId/cars/:carId', async (req, res) => {
  try {
    const db = await readDatabase();
    const dealership = db.dealerships.find(d => d.id === parseInt(req.params.dealershipId));
    if (!dealership) {
      return res.status(404).json({ error: 'Dealership not found' });
    }
    const carIndex = dealership.inventory.findIndex(c => c.id === parseInt(req.params.carId));
    if (carIndex === -1) {
      return res.status(404).json({ error: 'Car not found' });
    }
    dealership.inventory[carIndex] = {
      ...dealership.inventory[carIndex],
      ...req.body,
      id: parseInt(req.params.carId)
    };
    await writeDatabase(db);
    res.json(dealership.inventory[carIndex]);
  } catch (error) {
    console.error('Error updating car:', error);
    res.status(500).json({ error: 'Failed to update car' });
  }
});

// Delete car
app.delete('/api/dealerships/:dealershipId/cars/:carId', async (req, res) => {
  try {
    const db = await readDatabase();
    const dealership = db.dealerships.find(d => d.id === parseInt(req.params.dealershipId));
    if (!dealership) {
      return res.status(404).json({ error: 'Dealership not found' });
    }
    dealership.inventory = dealership.inventory.filter(c => c.id !== parseInt(req.params.carId));
    await writeDatabase(db);
    res.json({ success: true });
  } catch (error) {
    console.error('Error deleting car:', error);
    res.status(500).json({ error: 'Failed to delete car' });
  }
});

// Get all cars across all dealerships
app.get('/api/cars', async (req, res) => {
  try {
    const db = await readDatabase();
    const allCars = [];
    db.dealerships.forEach(dealership => {
      dealership.inventory.forEach(car => {
        allCars.push({
          ...car,
          dealershipId: dealership.id,
          dealershipName: dealership.name,
          dealershipLocation: dealership.location
        });
      });
    });
    res.json(allCars);
  } catch (error) {
    console.error('Error reading cars:', error);
    res.status(500).json({ error: 'Failed to read cars' });
  }
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Start server
initDatabase().then(() => {
  app.listen(PORT, '0.0.0.0', () => {
    console.log('🚀 Car Inventory System is running!');
    console.log(`📍 Server: http://0.0.0.0:${PORT}`);
    console.log(`📊 Database: ${DB_FILE}`);
    console.log(`✨ Ready to manage your inventory!`);
  });
});
